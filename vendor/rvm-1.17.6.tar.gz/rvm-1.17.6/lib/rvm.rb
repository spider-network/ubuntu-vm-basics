# == Ruby Version Manager - Ruby API

raise "RVM - Ruby integration was extracted to a separate gem, \
it should be installed by default with RVM, \
remove the `$LOAD_PATH.unshift` line and all should be fine again.
Visit https://rvm.io/integration/passenger for more details."
